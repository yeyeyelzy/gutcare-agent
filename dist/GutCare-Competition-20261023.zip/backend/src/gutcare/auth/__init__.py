"""Patient account authentication module."""
