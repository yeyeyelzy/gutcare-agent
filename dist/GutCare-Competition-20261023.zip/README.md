# GutCare 竞赛可运行程序包

本 ZIP 是竞赛材料第 4 项“可运行程序包、部署与环境配置说明”的直接提交文件；随包提供的说明见 [`docs/可运行程序包、部署与环境配置说明.md`](docs/可运行程序包、部署与环境配置说明.md)。本包用于 Windows 本机隔离演示，使用合成测试数据。不要导入真实患者资料，也不要将其作为生产部署方案。

## 包内内容

- `compose.phone-demo.yaml`：隔离演示服务编排，包含 FastAPI、PostgreSQL、Redis、MinIO、ClamAV、Mailpit，以及可选 Agent worker。
- `backend/`、`agent/`、`contracts/`、`infra/`：编排所需源码、数据库迁移、接口契约和初始化配置。
- `scripts/`：本地启动、停止和演示检查脚本。
- `Start-GutCareDemo.ps1`、`Stop-GutCareDemo.ps1`、`Verify-GutCarePackage.ps1`：包根的一键启动、停止和文件校验入口；源脚本也保存在 `scripts/`。
- `android/`：原生 Android Studio 工程及 `app-debug.apk`。
- `demo-materials/competition-demo/`：来源说明标记为从零合成的虚构报告与图片素材。
- `docs/`：部署、演示、隐私和来源边界说明，包含竞赛材料第 4 项运行说明。
- `SHA256SUMS.txt`：包内文件校验值。

## 启动后端

前置条件：Windows 10/11、Docker Desktop（含 Compose v2）、PowerShell。首次启动需要网络访问镜像仓库和固定版本 MinIO 构建依赖；脚本会在当前包目录下生成本机 `phone-demo.env`，只用于此隔离演示，不要复制到仓库或共享。

在解压目录中打开 PowerShell，先校验文件清单再启动：

```powershell
.\Verify-GutCarePackage.ps1
.\Start-GutCareDemo.ps1
```

竞赛包使用独立 Compose 项目 `gutcare-competition-demo` 和独立数据卷；仓库开发用 `gutcare-phone-demo` 的数据会保留。首次启动需要网络拉取 Docker 镜像及准备固定版本的 MinIO 构建依赖。启动器会检查 Docker Desktop/Compose 和 APK，安全拒绝含 live 模型配置的本机 `.env.agent.local`，再以 `mock` 模式启动并等待 `http://127.0.0.1:8000/health/live` 成功；不会显示模型密钥或清理数据。启动失败时会附带该竞赛项目最近 80 行 API 日志，并遮盖本机配置中的密码、Token、密钥和 pepper。Mailpit 演示邮件查看地址为 `http://127.0.0.1:8025`。

2026-10-23 本机运行验收结果：Compose 启动 22/22；API、Agent 和 dispatchers 健康；一次性 `minio-init` 正常退出；`GET /health/live` 返回 HTTP 200 和 `{"status":"alive"}`；Agent 模式为 `mock`。

首次运行请在解压后的包根目录执行：

```powershell
.\Verify-GutCarePackage.ps1
.\Start-GutCareDemo.ps1
```

维护者快速复验路径（仅用于首次运行已成功、镜像和本地配置已缓存的目录）：

```powershell
docker compose --profile agent -f .\compose.phone-demo.yaml --env-file .\phone-demo.env -p gutcare-competition-demo up -d --no-build --pull never --wait
Invoke-RestMethod http://127.0.0.1:8000/health/live | ConvertTo-Json -Compress
docker compose --profile agent -f .\compose.phone-demo.yaml --env-file .\phone-demo.env -p gutcare-competition-demo exec -T agent python -c "from gutcare_agents.config import load_settings; print(load_settings().mode)"
```

预期为服务健康、`{"status":"alive"}` 和 `mock`。此路径不会构建或拉取镜像；如果本地镜像缺失，改用首次运行步骤。停止演示请运行 `Stop-GutCareDemo.ps1`；它会停止竞赛项目容器并保留数据库、邮件和上传对象卷。之后可使用同一个本地 `phone-demo.env` 重新启动。

## 运行 Android 客户端

推荐在 Android Studio 打开包内 `android/`，安装 Android SDK Platform 36、Build Tools 36.0.0，配置 JDK 17，再启动 Android 模拟器并运行 `app` 的 Debug 变体。模拟器通过 `10.0.2.2:8000` 访问宿主机 API。

也可安装预置的 `android/app-debug.apk`：

```powershell
adb install -r .\android\app-debug.apk
```

APK 为 debug 签名，仅供本地演示。包内 APK 元数据为 `com.gutcare.app`、debug、`0.1.0`。此 APK 沿用本机 Android 构建与模拟器排障记录中成功覆盖安装的调试产物；其生成时间晚于当前主源码文件的最新修改时间。本次复建因 Gradle Wrapper 下载受网络限制未能完成，也未重新执行模拟器验收，因此请将 APK 视为便捷演示副本；需要确认源码版本时，请用 Android Studio 从包内源码构建后运行。过程记录见 `docs/Android构建与模拟器更新排障记录-20261023.md`。

## 停止服务与核验

```powershell
.\Stop-GutCareDemo.ps1
.\Verify-GutCarePackage.ps1
```

停止脚本只停止容器，会保留演示数据库、邮件和上传对象。不要使用 `-PurgeData`，除非明确希望永久删除本项目演示卷。校验脚本会核对 `SHA256SUMS.txt` 中的文件及必要启动文件。

## 限制

- 仅用于本地隔离测试/竞赛演示，禁止真实患者数据、临床使用或生产上线。
- 默认 Agent mock；识别候选不是患者事实，需按流程确认；不代表医学有效性。
- Android 仍需由评审方在 Android Studio 模拟器验收。真机、生产、备份恢复、法律和专业审核均不包含在本包验收内。
- 本次后端与 Compose 运行验收证据截至 2026-10-23；不代表 Android UI/真机、生产环境、备份恢复、法律或专业审核完成。
- Agent 来源记录见 `agent/PROVENANCE.md`：项目负责人已确认可将源码公开提交至当前项目仓库，但上游快照没有附带开源许可证。本包仅供竞赛评审检查，不授予赛方或其他第三方再发布、再许可或商业分发权。
- 文件来源与组件、数据边界分别见 `demo-materials/competition-demo/README.md`、`docs/开源组件、第三方模型与数据使用说明.md`。
